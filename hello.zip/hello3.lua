function mytime(x, y)
    return x * y
end